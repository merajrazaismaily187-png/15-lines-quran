15 Lines Hefz Quran - Android WebView project

This project wraps the supplied HTML app in an Android WebView.

FIXED:
- Corrected the JavaScript back-button result string syntax in MainActivity.java.
- Kept JavaScript, DOM storage and local asset access enabled for the HTML app.

IMPORTANT:
The supplied HTML expects licensed Quran page images at:
app/src/main/assets/pages/page-001.jpg ... page-604.jpg

Those 604 images were NOT included in the uploaded ZIP. They must be added before
building the final APK if the Quran pages are to display. Do not use copyrighted
or unlicensed page scans.

Optional:
- Add your final app icon/logo through the Android project resources before release.
- For Google Play, generate a signed AAB rather than relying on a debug APK.

SVG VERSION:
Place licensed Quran page files in app/src/main/assets/pages/ using names page-001.svg through page-604.svg. The HTML has been updated to reference .svg files.
